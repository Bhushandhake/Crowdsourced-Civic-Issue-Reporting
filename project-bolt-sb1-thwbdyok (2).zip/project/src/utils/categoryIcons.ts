import { 
  Trash2, 
  Construction, 
  Lightbulb, 
  Droplets, 
  AlertCircle 
} from 'lucide-react';

export const categoryIcons = {
  Garbage: Trash2,
  Pothole: Construction,
  Streetlight: Lightbulb,
  Water: Droplets,
  Other: AlertCircle,
};

export const categoryColors = {
  Garbage: 'text-green-600 bg-green-100',
  Pothole: 'text-orange-600 bg-orange-100',
  Streetlight: 'text-yellow-600 bg-yellow-100',
  Water: 'text-blue-600 bg-blue-100',
  Other: 'text-gray-600 bg-gray-100',
};