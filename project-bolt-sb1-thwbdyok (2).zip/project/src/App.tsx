import React, { useState } from 'react';
import { Page } from './types';
import { useIssues } from './hooks/useIssues';
import { useAuth } from './hooks/useAuth';
import { Header } from './components/Header';
import { LoginPage } from './components/LoginPage';
import { ChatBot } from './components/ChatBot';
import { HomePage } from './components/pages/HomePage';
import { ReportIssuePage } from './components/pages/ReportIssuePage';
import { IssuesPage } from './components/pages/IssuesPage';
import { MapPage } from './components/pages/MapPage';
import { AboutPage } from './components/pages/AboutPage';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { issues, addIssue, updateIssueStatus } = useIssues();
  const { user, isAuthenticated, isLoading, login, logout } = useAuth();

  const handleMenuToggle = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handlePageChange = (page: Page) => {
    setCurrentPage(page);
    setIsMenuOpen(false);
  };

  // Show login page if not authenticated
  if (!isAuthenticated) {
    return <LoginPage onLogin={login} isLoading={isLoading} />;
  }

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onPageChange={handlePageChange} issuesCount={issues.length} />;
      case 'report':
        return <ReportIssuePage onAddIssue={addIssue} onPageChange={handlePageChange} />;
      case 'issues':
        return <IssuesPage issues={issues} onUpdateStatus={updateIssueStatus} />;
      case 'map':
        return <MapPage issues={issues} />;
      case 'about':
        return <AboutPage />;
      default:
        return <HomePage onPageChange={handlePageChange} issuesCount={issues.length} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header
        currentPage={currentPage}
        onPageChange={handlePageChange}
        isMenuOpen={isMenuOpen}
        onMenuToggle={handleMenuToggle}
        user={user}
        onLogout={logout}
      />
      {renderCurrentPage()}
      <ChatBot />
    </div>
  );
}

export default App;