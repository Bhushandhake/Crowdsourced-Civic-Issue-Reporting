import React from 'react';
import { Issue } from '../types';
import { MapPin, Calendar, ChevronDown } from 'lucide-react';
import { categoryIcons, categoryColors } from '../utils/categoryIcons';

interface IssueCardProps {
  issue: Issue;
  onUpdateStatus: (id: string, status: Issue['status']) => void;
}

export function IssueCard({ issue, onUpdateStatus }: IssueCardProps) {
  const IconComponent = categoryIcons[issue.category];
  
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const getStatusColor = (status: Issue['status']) => {
    switch (status) {
      case 'Pending': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'In Progress': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'Resolved': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200';
    }
  };

  const statusOptions: Issue['status'][] = ['Pending', 'In Progress', 'Resolved'];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200 overflow-hidden">
      {/* Image */}
      {issue.photo && (
        <div className="h-48 bg-gray-200 dark:bg-gray-700 overflow-hidden">
          <img
            src={issue.photo}
            alt={issue.title}
            className="w-full h-full object-cover"
          />
        </div>
      )}

      <div className="p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center space-x-2">
            <div className={`p-1.5 rounded-full ${categoryColors[issue.category]} dark:bg-opacity-20`}>
              <IconComponent className="h-4 w-4" />
            </div>
            <span className={`px-2 py-1 text-xs font-medium rounded-full ${categoryColors[issue.category]} dark:bg-opacity-20`}>
              {issue.category}
            </span>
          </div>
        </div>

        {/* Title */}
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2 line-clamp-2">
          {issue.title}
        </h3>

        {/* Description */}
        <p className="text-gray-600 dark:text-gray-300 text-sm mb-4 line-clamp-3">
          {issue.description}
        </p>

        {/* Location and Date */}
        <div className="space-y-2 mb-4">
          <div className="flex items-center text-gray-500 dark:text-gray-400 text-sm">
            <MapPin className="h-4 w-4 mr-1 flex-shrink-0" />
            <span className="truncate">{issue.location}</span>
          </div>
          <div className="flex items-center text-gray-500 dark:text-gray-400 text-sm">
            <Calendar className="h-4 w-4 mr-1 flex-shrink-0" />
            <span>Reported {formatDate(issue.createdAt)}</span>
          </div>
        </div>

        {/* Status and Actions */}
        <div className="flex items-center justify-between">
          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(issue.status)}`}>
            {issue.status}
          </span>

          <div className="relative">
            <select
              value={issue.status}
              onChange={(e) => onUpdateStatus(issue.id, e.target.value as Issue['status'])}
              className="appearance-none bg-gray-50 border border-gray-300 text-gray-700 py-1 px-2 pr-8 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300 dark:focus:ring-blue-400"
            >
              {statusOptions.map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-1 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
          </div>
        </div>
      </div>
    </div>
  );
}