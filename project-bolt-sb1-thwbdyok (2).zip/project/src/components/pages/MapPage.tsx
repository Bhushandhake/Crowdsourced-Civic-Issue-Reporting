import React, { useState } from 'react';
import { Issue } from '../../types';
import { MapPin, X } from 'lucide-react';
import { categoryIcons, categoryColors } from '../../utils/categoryIcons';

interface MapPageProps {
  issues: Issue[];
}

export function MapPage({ issues }: MapPageProps) {
  const [selectedIssue, setSelectedIssue] = useState<Issue | null>(null);

  // Simple map bounds for demonstration
  const mapBounds = {
    minLat: 40.65,
    maxLat: 40.8,
    minLng: -74.1,
    maxLng: -73.9,
  };

  const normalizeCoordinate = (coord: number, min: number, max: number) => {
    return ((coord - min) / (max - min)) * 100;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const getStatusColor = (status: Issue['status']) => {
    switch (status) {
      case 'Pending': return 'bg-yellow-500';
      case 'In Progress': return 'bg-blue-500';
      case 'Resolved': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="h-screen bg-gray-50 dark:bg-gray-900 relative">
      {/* Map Container */}
      <div className="h-full relative bg-gradient-to-br from-green-50 to-blue-50 dark:from-gray-800 dark:to-gray-700 overflow-hidden">
        {/* Map Background Pattern */}
        <div 
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `
              linear-gradient(rgba(59, 130, 246, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(59, 130, 246, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: '20px 20px'
          }}
        />
        
        {/* Streets simulation */}
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-0 right-0 h-1 bg-gray-300 dark:bg-gray-600 opacity-60" />
          <div className="absolute top-2/4 left-0 right-0 h-1 bg-gray-300 dark:bg-gray-600 opacity-60" />
          <div className="absolute top-3/4 left-0 right-0 h-1 bg-gray-300 dark:bg-gray-600 opacity-60" />
          <div className="absolute left-1/4 top-0 bottom-0 w-1 bg-gray-300 dark:bg-gray-600 opacity-60" />
          <div className="absolute left-2/4 top-0 bottom-0 w-1 bg-gray-300 dark:bg-gray-600 opacity-60" />
          <div className="absolute left-3/4 top-0 bottom-0 w-1 bg-gray-300 dark:bg-gray-600 opacity-60" />
        </div>

        {/* Map Header */}
        <div className="absolute top-0 left-0 right-0 bg-white dark:bg-gray-800 shadow-sm z-20 p-4">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">
              Issue Map View
            </h1>
            <div className="text-sm text-gray-600 dark:text-gray-400">
              {issues.length} issues displayed
            </div>
          </div>
        </div>

        {/* Issue Markers */}
        {issues.map((issue) => {
          const IconComponent = categoryIcons[issue.category];
          const x = normalizeCoordinate(issue.coordinates.lng, mapBounds.minLng, mapBounds.maxLng);
          const y = normalizeCoordinate(issue.coordinates.lat, mapBounds.minLat, mapBounds.maxLat);

          return (
            <div
              key={issue.id}
              className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer z-10"
              style={{
                left: `${x}%`,
                top: `${100 - y}%`,
              }}
              onClick={() => setSelectedIssue(issue)}
            >
              <div className={`relative p-2 rounded-full ${getStatusColor(issue.status)} shadow-lg hover:scale-110 transition-transform duration-200`}>
                <IconComponent className="h-5 w-5 text-white" />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-white rounded-full border border-gray-300" />
              </div>
            </div>
          );
        })}

        {/* Legend */}
        <div className="absolute bottom-4 left-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4 z-20">
          <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Legend</h3>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-yellow-500 rounded-full" />
              <span className="text-sm text-gray-600 dark:text-gray-400">Pending</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full" />
              <span className="text-sm text-gray-600 dark:text-gray-400">In Progress</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full" />
              <span className="text-sm text-gray-600 dark:text-gray-400">Resolved</span>
            </div>
          </div>
        </div>

        {/* Category Legend */}
        <div className="absolute bottom-4 right-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4 z-20">
          <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Categories</h3>
          <div className="space-y-2">
            {Object.entries(categoryIcons).map(([category, IconComponent]) => (
              <div key={category} className="flex items-center space-x-2">
                <IconComponent className="h-4 w-4 text-gray-600 dark:text-gray-400" />
                <span className="text-sm text-gray-600 dark:text-gray-400">{category}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Issue Details Modal */}
      {selectedIssue && (
        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center z-30 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-md w-full max-h-96 overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  {selectedIssue.title}
                </h3>
                <button
                  onClick={() => setSelectedIssue(null)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    selectedIssue.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' :
                    selectedIssue.status === 'In Progress' ? 'bg-blue-100 text-blue-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {selectedIssue.status}
                  </span>
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${categoryColors[selectedIssue.category]}`}>
                    {selectedIssue.category}
                  </span>
                </div>

                {selectedIssue.photo && (
                  <img
                    src={selectedIssue.photo}
                    alt="Issue"
                    className="w-full h-32 object-cover rounded-lg"
                  />
                )}

                <div>
                  <h4 className="font-medium text-gray-900 dark:text-white mb-1">Description</h4>
                  <p className="text-gray-600 dark:text-gray-300 text-sm">
                    {selectedIssue.description}
                  </p>
                </div>

                <div>
                  <h4 className="font-medium text-gray-900 dark:text-white mb-1">Location</h4>
                  <p className="text-gray-600 dark:text-gray-300 text-sm flex items-center">
                    <MapPin className="h-4 w-4 mr-1" />
                    {selectedIssue.location}
                  </p>
                </div>

                <div>
                  <h4 className="font-medium text-gray-900 dark:text-white mb-1">Reported</h4>
                  <p className="text-gray-600 dark:text-gray-300 text-sm">
                    {formatDate(selectedIssue.createdAt)}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}