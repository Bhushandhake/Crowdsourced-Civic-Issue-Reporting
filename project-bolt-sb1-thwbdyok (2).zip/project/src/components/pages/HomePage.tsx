import React from 'react';
import { Page } from '../../types';
import { MapPin, Users, CheckCircle, Clock } from 'lucide-react';

interface HomePageProps {
  onPageChange: (page: Page) => void;
  issuesCount: number;
}

export function HomePage({ onPageChange, issuesCount }: HomePageProps) {
  const stats = [
    { name: 'Total Issues', value: issuesCount, icon: MapPin, color: 'text-blue-600' },
    { name: 'Community Members', value: '1,234', icon: Users, color: 'text-green-600' },
    { name: 'Resolved Issues', value: '89', icon: CheckCircle, color: 'text-purple-600' },
    { name: 'Avg Response Time', value: '2.5 days', icon: Clock, color: 'text-orange-600' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-white dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-4xl font-extrabold text-gray-900 dark:text-white sm:text-5xl md:text-6xl">
              Make Your City <span className="text-blue-600">Better</span>
            </h1>
            <p className="mt-3 max-w-md mx-auto text-base text-gray-500 dark:text-gray-300 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
              Report civic issues in your neighborhood and help build a stronger community. 
              Your voice matters, and together we can create positive change.
            </p>
            <div className="mt-5 max-w-md mx-auto sm:flex sm:justify-center md:mt-8">
              <div className="rounded-md shadow">
                <button
                  onClick={() => onPageChange('report')}
                  className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 md:py-4 md:text-lg md:px-10 transition-colors duration-200"
                >
                  Report an Issue
                </button>
              </div>
              <div className="mt-3 rounded-md shadow sm:mt-0 sm:ml-3">
                <button
                  onClick={() => onPageChange('issues')}
                  className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-blue-600 bg-white hover:bg-gray-50 dark:bg-gray-700 dark:text-blue-400 dark:hover:bg-gray-600 md:py-4 md:text-lg md:px-10 transition-colors duration-200"
                >
                  View Issues
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="bg-gray-50 dark:bg-gray-900 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {stats.map((stat) => (
              <div
                key={stat.name}
                className="bg-white dark:bg-gray-800 overflow-hidden shadow rounded-lg"
              >
                <div className="p-5">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <stat.icon className={`h-6 w-6 ${stat.color}`} />
                    </div>
                    <div className="ml-5 w-0 flex-1">
                      <dl>
                        <dt className="text-sm font-medium text-gray-500 dark:text-gray-300 truncate">
                          {stat.name}
                        </dt>
                        <dd className="text-lg font-medium text-gray-900 dark:text-white">
                          {stat.value}
                        </dd>
                      </dl>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-16 bg-white dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:text-center">
            <h2 className="text-base text-blue-600 font-semibold tracking-wide uppercase">
              How it Works
            </h2>
            <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 dark:text-white sm:text-4xl">
              Simple steps to make a difference
            </p>
          </div>

          <div className="mt-10">
            <div className="space-y-10 md:space-y-0 md:grid md:grid-cols-3 md:gap-x-8 md:gap-y-10">
              <div className="relative">
                <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white font-bold text-lg">
                  1
                </div>
                <p className="ml-16 text-lg leading-6 font-medium text-gray-900 dark:text-white">
                  Report the Issue
                </p>
                <p className="mt-2 ml-16 text-base text-gray-500 dark:text-gray-300">
                  Describe the problem, add a photo, and specify the location. Your report helps us understand what needs attention.
                </p>
              </div>

              <div className="relative">
                <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white font-bold text-lg">
                  2
                </div>
                <p className="ml-16 text-lg leading-6 font-medium text-gray-900 dark:text-white">
                  Community Review
                </p>
                <p className="mt-2 ml-16 text-base text-gray-500 dark:text-gray-300">
                  Other community members can view and support your report, creating a stronger voice for change.
                </p>
              </div>

              <div className="relative">
                <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white font-bold text-lg">
                  3
                </div>
                <p className="ml-16 text-lg leading-6 font-medium text-gray-900 dark:text-white">
                  Track Progress
                </p>
                <p className="mt-2 ml-16 text-base text-gray-500 dark:text-gray-300">
                  Follow the status of your report from pending to in progress to resolved. See the impact you're making.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}