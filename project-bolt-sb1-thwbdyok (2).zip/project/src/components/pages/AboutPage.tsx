import React from 'react';
import { Users, Target, Heart, Award } from 'lucide-react';

export function AboutPage() {
  const features = [
    {
      name: 'Community Driven',
      description: 'Built by the community, for the community. Every report makes a difference.',
      icon: Users,
    },
    {
      name: 'Focused Impact',
      description: 'Direct your civic engagement where it matters most in your neighborhood.',
      icon: Target,
    },
    {
      name: 'Social Good',
      description: 'Contributing to a better, more responsive local government and community.',
      icon: Heart,
    },
    {
      name: 'Proven Results',
      description: 'Track record of helping resolve hundreds of civic issues across communities.',
      icon: Award,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="text-center">
          <h1 className="text-4xl font-extrabold text-gray-900 dark:text-white sm:text-5xl">
            About Civic Reporter
          </h1>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500 dark:text-gray-300">
            Empowering communities to create positive change through collaborative civic engagement 
            and transparent issue reporting.
          </p>
        </div>

        {/* Mission Section */}
        <div className="mt-20">
          <div className="lg:grid lg:grid-cols-2 lg:gap-8 lg:items-center">
            <div>
              <h2 className="text-3xl font-extrabold text-gray-900 dark:text-white sm:text-4xl">
                Our Mission
              </h2>
              <p className="mt-3 max-w-3xl text-lg text-gray-500 dark:text-gray-300">
                Civic Reporter was created to bridge the gap between community members and local 
                government by providing a simple, effective platform for reporting and tracking 
                civic issues.
              </p>
              <p className="mt-3 max-w-3xl text-lg text-gray-500 dark:text-gray-300">
                We believe that when citizens have an easy way to report problems and track their 
                resolution, communities become stronger, more responsive, and more livable for everyone.
              </p>
            </div>
            <div className="mt-8 lg:mt-0">
              <div className="bg-white dark:bg-gray-800 shadow rounded-lg p-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">2,000+</div>
                  <div className="text-gray-600 dark:text-gray-400 mb-4">Issues Reported</div>
                  <div className="text-3xl font-bold text-green-600 mb-2">85%</div>
                  <div className="text-gray-600 dark:text-gray-400 mb-4">Resolution Rate</div>
                  <div className="text-3xl font-bold text-purple-600 mb-2">150+</div>
                  <div className="text-gray-600 dark:text-gray-400">Communities Served</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <div className="mt-20">
          <div className="lg:text-center">
            <h2 className="text-base text-blue-600 font-semibold tracking-wide uppercase">
              Why Choose Us
            </h2>
            <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 dark:text-white sm:text-4xl">
              Making civic engagement accessible
            </p>
            <p className="mt-4 max-w-2xl text-xl text-gray-500 dark:text-gray-300 lg:mx-auto">
              We've designed every aspect of our platform to make reporting and tracking civic 
              issues as simple and effective as possible.
            </p>
          </div>

          <div className="mt-10">
            <div className="space-y-10 md:space-y-0 md:grid md:grid-cols-2 md:gap-x-8 md:gap-y-10">
              {features.map((feature) => (
                <div key={feature.name} className="relative">
                  <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white">
                    <feature.icon className="h-6 w-6" aria-hidden="true" />
                  </div>
                  <p className="ml-16 text-lg leading-6 font-medium text-gray-900 dark:text-white">
                    {feature.name}
                  </p>
                  <p className="mt-2 ml-16 text-base text-gray-500 dark:text-gray-300">
                    {feature.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* How It Works Section */}
        <div className="mt-20">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8">
            <h2 className="text-3xl font-extrabold text-gray-900 dark:text-white text-center mb-8">
              How It Works
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="bg-blue-500 text-white rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                  1
                </div>
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                  Report the Issue
                </h3>
                <p className="text-gray-500 dark:text-gray-300">
                  Use our simple form to describe the problem, add photos, and specify the location.
                </p>
              </div>
              <div className="text-center">
                <div className="bg-blue-500 text-white rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                  2
                </div>
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                  Community Review
                </h3>
                <p className="text-gray-500 dark:text-gray-300">
                  Issues are visible to the community, creating transparency and collective awareness.
                </p>
              </div>
              <div className="text-center">
                <div className="bg-blue-500 text-white rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                  3
                </div>
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                  Track Progress
                </h3>
                <p className="text-gray-500 dark:text-gray-300">
                  Monitor the status of your report from pending to in progress to resolved.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Project Info */}
        <div className="mt-20 bg-gray-100 dark:bg-gray-800 rounded-lg p-8">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              Hackathon Project
            </h2>
            <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Civic Reporter was developed as part of a hackathon focused on creating technology 
              solutions for social good. Our goal was to demonstrate how modern web technologies 
              can be used to strengthen the connection between citizens and their local communities, 
              making civic engagement more accessible and effective for everyone.
            </p>
            <p className="mt-4 text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Built with React, TypeScript, and TailwindCSS, this project showcases a responsive, 
              user-friendly interface that works across all devices while maintaining data locally 
              for a fast, reliable experience.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}