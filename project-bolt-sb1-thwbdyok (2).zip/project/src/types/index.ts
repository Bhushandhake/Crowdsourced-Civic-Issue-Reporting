export interface Issue {
  id: string;
  title: string;
  category: 'Garbage' | 'Pothole' | 'Streetlight' | 'Water' | 'Other';
  description: string;
  location: string;
  photo?: string;
  status: 'Pending' | 'In Progress' | 'Resolved';
  createdAt: string;
  coordinates: { lat: number; lng: number };
}

export type Page = 'home' | 'report' | 'issues' | 'map' | 'about';

export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: string;
}