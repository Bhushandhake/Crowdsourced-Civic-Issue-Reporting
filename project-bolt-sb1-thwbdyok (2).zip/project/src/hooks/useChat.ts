import { useState } from 'react';
import { useLocalStorage } from './useLocalStorage';
import { ChatMessage } from '../types';

export function useChat() {
  const [messages, setMessages] = useLocalStorage<ChatMessage[]>('civic-reporter-chat', []);
  const [isTyping, setIsTyping] = useState(false);

  const sendMessage = async (content: string) => {
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      content,
      sender: 'user',
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMessage]);
    setIsTyping(true);

    // Simulate AI response delay
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));

    const aiResponse = generateAIResponse(content);
    const aiMessage: ChatMessage = {
      id: (Date.now() + 1).toString(),
      content: aiResponse,
      sender: 'ai',
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, aiMessage]);
    setIsTyping(false);
  };

  const clearChat = () => {
    setMessages([]);
  };

  return {
    messages,
    isTyping,
    sendMessage,
    clearChat,
  };
}

function generateAIResponse(userMessage: string): string {
  const message = userMessage.toLowerCase();
  
  // Issue reporting help
  if (message.includes('report') || message.includes('issue') || message.includes('problem')) {
    return "I can help you report civic issues! To report an issue, go to the 'Report Issue' page and fill out the form with details like the title, category (Garbage, Pothole, Streetlight, Water, or Other), description, and location. You can also upload a photo to help illustrate the problem. The more details you provide, the better!";
  }
  
  // Status updates
  if (message.includes('status') || message.includes('update') || message.includes('progress')) {
    return "You can track the status of reported issues on the 'Issues' page. Each issue has a status that can be updated: Pending (newly reported), In Progress (being worked on), or Resolved (completed). Community members and administrators can update these statuses to keep everyone informed.";
  }
  
  // Map help
  if (message.includes('map') || message.includes('location') || message.includes('where')) {
    return "The Map page shows all reported issues with visual markers on an interactive map. Each marker represents an issue, and you can click on them to see details. The markers are color-coded by status: yellow for pending, blue for in progress, and green for resolved issues.";
  }
  
  // Categories
  if (message.includes('category') || message.includes('type')) {
    return "We have 5 main categories for civic issues: 🗑️ Garbage (waste management, litter), 🚧 Pothole (road maintenance), 💡 Streetlight (lighting issues), 💧 Water (plumbing, drainage), and ⚠️ Other (miscellaneous civic concerns). Choose the category that best fits your issue when reporting.";
  }
  
  // General help
  if (message.includes('help') || message.includes('how') || message.includes('?')) {
    return "I'm here to help you navigate Civic Reporter! You can ask me about reporting issues, checking status updates, using the map, understanding categories, or any other questions about the platform. What would you like to know more about?";
  }
  
  // Greeting
  if (message.includes('hello') || message.includes('hi') || message.includes('hey')) {
    return "Hello! Welcome to Civic Reporter. I'm your AI assistant, here to help you report civic issues and navigate the platform. How can I assist you today?";
  }
  
  // Default responses
  const defaultResponses = [
    "That's an interesting question! For civic issues, I recommend using our reporting system to document problems in your community. Is there a specific issue you'd like to report?",
    "I'm here to help with civic reporting and community issues. You can report problems, track their status, and view them on our interactive map. What would you like to know more about?",
    "Thanks for using Civic Reporter! If you're experiencing a civic issue in your community, I can guide you through the reporting process. Would you like help with that?",
    "I can help you with reporting civic issues, understanding our categories, tracking status updates, and using the map feature. What specific assistance do you need?",
  ];
  
  return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
}