import { useLocalStorage } from './useLocalStorage';
import { Issue } from '../types';

export function useIssues() {
  const [issues, setIssues] = useLocalStorage<Issue[]>('civic-reporter-issues', []);

  const addIssue = (issue: Omit<Issue, 'id' | 'createdAt' | 'coordinates'>) => {
    const newIssue: Issue = {
      ...issue,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      coordinates: generateRandomCoordinates(),
    };
    setIssues(prev => [newIssue, ...prev]);
    return newIssue;
  };

  const updateIssueStatus = (id: string, status: Issue['status']) => {
    setIssues(prev => 
      prev.map(issue => 
        issue.id === id ? { ...issue, status } : issue
      )
    );
  };

  return {
    issues,
    addIssue,
    updateIssueStatus,
  };
}

// Generate random coordinates within a city area for demonstration
function generateRandomCoordinates(): { lat: number; lng: number } {
  const baseLat = 40.7128; // NYC area
  const baseLng = -74.0060;
  const variance = 0.05;
  
  return {
    lat: baseLat + (Math.random() - 0.5) * variance,
    lng: baseLng + (Math.random() - 0.5) * variance,
  };
}